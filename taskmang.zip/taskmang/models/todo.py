from odoo import models, fields, api
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class Todo(models.Model):
    _name = 'todo'
    _description ='todo'
    _inherit =['mail.thread' ,'mail.activity.mixin']

    name = fields.Char(required=1, size=12 , default ='New')
    description = fields.Text()
    assign_to =  fields.Many2one('res.partner')
    due_date = fields.Date(tracking=1)
    expected_date = fields.Date(tracking=1)
    is_late = fields.Boolean()
    estimated_time = fields.Datetime()
    active = fields.Boolean(default=True)
    state = fields.Selection([
        ('new','New'),
        ('inprogress','In Progress'),
        ('complete','Complete'),
        ('closed','Closed'),
    ],default='new')
    
    status = fields.Selection([
        ('new','New'),
        ('inprogress','In Progress'),
        ('complete','Complete'),
    ],default='new')

    line_ids= fields.One2many(comodel_name='todo.line',inverse_name='todo_id')

   
    @api.model
    def _search(self, domain, offset=0, limit=None, order=None, access_rights_uid=None):
        res = super(Todo, self)._search(domain, offset=offset, limit=limit, order=order, access_rights_uid=access_rights_uid)
        _logger.info("inside search method")
        return res
    
    def action_new(self): 
        for rec in self:
            _logger.info("inside new action")
            rec.state='new'

    def action_inprogress(self): 
        for rec in self:
            _logger.info("inside inprogress action")
            rec.write({
                'state':'inprogress'
            })
    
    def action_complete(self): 
        for rec in self:
            _logger.info("inside complete action")
            rec.state='complete'

    def action_closed(self):
        for rec in self :
            rec.state= 'closed'

    def check_expected_date(self):
        todo_ids=self.search([])
        for rec in todo_ids : 
            if rec.expected_date and rec.expected_date < fields.date.today():
                rec.is_late =True 



class TodoLine(models.Model):
    _name = 'todo.line'

    todo_id = fields.Many2one('todo')    
    time = fields.Datetime()
    description = fields.Char()
