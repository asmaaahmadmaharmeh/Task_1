{
    'name' : "Task To Do",
    'author' : "Asmaa Maharmeh",
    'category' :'',
    'version' :'17.0.0.1.0',
    'license': 'LGPL-3',
    'depends' :[
        'base',
        'mail',
        'contacts',
        ],
    'data':[
        'security/ir.model.access.csv',
        'views/base_menu.xml',
        'views/todo_view.xml',
        'reports/todo_report.xml' , 
    ],
    'assets':{
        'web.assets_backend':['taskmang/static/src/css/todo.css']
    },
    'application': True , 
}